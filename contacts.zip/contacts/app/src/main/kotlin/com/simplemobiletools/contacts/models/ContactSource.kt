package com.simplemobiletools.contacts.models

data class ContactSource(var name: String, var type: String)
