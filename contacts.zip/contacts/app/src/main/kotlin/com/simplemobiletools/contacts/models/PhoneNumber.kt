package com.simplemobiletools.contacts.models

data class PhoneNumber(var value: String, var type: Int)
