package com.simplemobiletools.contacts.models

data class Event(var value: String, var type: Int)
