package com.simplemobiletools.contacts.models

data class Email(var value: String, var type: Int)
