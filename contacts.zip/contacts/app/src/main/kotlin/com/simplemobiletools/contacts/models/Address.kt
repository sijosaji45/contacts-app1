package com.simplemobiletools.contacts.models

data class Address(var value: String, var type: Int)
