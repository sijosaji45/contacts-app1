package com.simplemobiletools.contacts.interfaces

interface RefreshContactsListener {
    fun refreshContacts(refreshTabsMask: Int)
}
